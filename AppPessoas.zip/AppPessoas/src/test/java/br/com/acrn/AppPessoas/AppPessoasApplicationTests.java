package br.com.acrn.AppPessoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPessoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
